import { ActivityHandler } from 'botbuilder';
export declare class MyBot extends ActivityHandler {
    constructor(configuration: any, qnaOptions: any);
}
